from tools import *


def Q2_results():
        # --- 1. Load feature datasets ---
    train_sNC_features = pd.read_csv(Global.sNC_train_path, header=None)
    train_sDAT_features = pd.read_csv(Global.sDAT_train_path, header=None)

    test_sNC_features = pd.read_csv(Global.sNC_test_path, header=None)
    test_sDAT_features = pd.read_csv(Global.sDAT_test_path, header=None)

    # Loading Grid for Background coloring
    grid_df = pd.read_csv("Data/grid_df.csv")

    # --- 2. Name columns and label target class ---
    train_sNC_features.columns=Global.columns_names
    train_sNC_features[Global.label_name]=Global.sNC_label


    # This is creating a column labeled "Target" and setting it to 0 (sNC)
    # I'm calling every label and target value from the Global enviroment so every
    # dataframe has the exact same names and everything

    train_sDAT_features.columns=Global.columns_names
    train_sDAT_features[Global.label_name]=Global.sDAT_label

    # ---- Concatenate to Create the total training

    train_features = pd.concat([train_sNC_features, train_sDAT_features], axis=0, ignore_index=True)
    #This data set looks like: x1 | x2 | Target (y) |
    #We now creat and X matrix with x1 | x2, and the target vector y
    X_train = train_features[Global.columns_names]
    Y_train = train_features[Global.label_name]


    if X_train.empty:
        print("Error: X_train is empty! Check your CSV files for valid data.")
        return

    #Do the same thing for the test data
    test_sNC_features.columns=Global.columns_names
    test_sNC_features[Global.label_name]=Global.sNC_label

    test_sDAT_features.columns=Global.columns_names
    test_sDAT_features[Global.label_name]=Global.sDAT_label

    test_features = pd.concat([test_sNC_features, test_sDAT_features], axis=0, ignore_index=True)
    X_test = test_features[Global.columns_names]
    Y_test = test_features[Global.label_name]

    if X_test.empty:
        print("Error: X_test  is empty! Check your CSV files for valid data.")
        return


    # We got k=30 as the best from question 1, so I don't think we need to redo that.
    k=30
    # Second Graph
    #Training The Manhattan Classifier
    clf_manhattan = KNeighborsClassifier(n_neighbors=k, metric='manhattan')
    clf_manhattan.fit(X_train, Y_train)

    man_train_error = 1-clf_manhattan.score(X_train, Y_train)
    man_test_error = 1-clf_manhattan.score(X_test, Y_test)

    skip=2 #We plot one every <skip> points in the data setting
    plot_train_nSC=train_sNC_features[::skip]
    plot_train_nDAT=train_sDAT_features[::skip]
    plot_test_nSC=test_sNC_features[::skip]
    plot_test_nDAT=test_sDAT_features[::skip]

    x1_range= (min(plot_train_nDAT['x1'].min(),
                   plot_test_nDAT['x1'].min()),
               max(plot_train_nSC['x1'].max(),
                   plot_test_nSC['x1'].max()))

    x2_range= (min(plot_train_nDAT['x2'].min(),
                   plot_test_nDAT['x2'].min()),
               max(plot_train_nSC['x2'].max(),
                   plot_test_nSC['x2'].max()))

    X_grid=grid_df[Global.columns_names]
    bg_colors=['#b2ffa9', '#889eff'] #Light Blue and Light Green
    cmap_background = ListedColormap(bg_colors)
    sqr_size=3
    alpha_value=0.3

    plt.title(f"kNN Classifier for k={k} Manhattan Metric \n Training Error = {man_test_error:.3f} , Test Error={man_test_error:.3f} \n plotting 1 in every {skip} points", fontsize='large')

    plt.xlabel(r'$x_1$')
    plt.ylabel(r'$x_2$')
    plt.xlim(x1_range)
    plt.ylim(x2_range)

    grid_df[Global.label_name]=clf_manhattan.predict(X_grid)
    grid_sNC = grid_df[grid_df[Global.label_name] == Global.sNC_label]
    grid_sDAT = grid_df[grid_df[Global.label_name] == Global.sDAT_label]


    plt.scatter(grid_sNC['x1'], grid_sNC['x2'],
                    c=bg_colors[0],
                    marker='s', s=sqr_size,
                    edgecolor='none', alpha=alpha_value)
    plt.scatter(grid_sDAT['x1'], grid_sDAT['x2'],
                   c=bg_colors[1],
                   marker='s', s=sqr_size,
                   edgecolor='none', alpha=alpha_value)

    plt.scatter(plot_train_nSC['x1'], plot_train_nSC['x2'],
                    color=Global.sNC_color,marker='o', label='0/sNC train')
    plt.scatter(plot_train_nDAT['x1'], plot_train_nDAT['x2'],
                    color=Global.sDAT_color,marker='o', label='1/sDAT train')

    plt.scatter(plot_test_nSC['x1'], plot_test_nSC['x2'],
                    color=Global.sNC_color,marker='x', label='0/sNC test')
    plt.scatter(plot_test_nDAT['x1'], plot_test_nDAT['x2'],
                    color=Global.sDAT_color,marker='x', label='1/sDAT test')

    # regions = {
    #         1: {'pos': (0.35, 0.03), 'name': 'sDAT Region'},
    #         0: {'pos': (0.85, 0.6), 'name': 'sNC \n Region'}
    #     }

    # for val, style in regions.items():
    #     plt.text(*style['pos'], style['name'])

    #     plt.legend(loc='upper left', fontsize='large')

    #plt.show()
    plt.savefig("Q2_single.png", dpi=300)


Q2_results()
